package com.example.sice.di

import com.example.marsphotos.repository.LocalRepository
import com.example.sice.data.MainRepository
import com.example.sice.data.MarsPhotosRepository
import com.example.sice.data.SNRepository
import kotlin.getValue

class DesktopAppContainer : AppContainer {
    override val marsPhotosRepository: MarsPhotosRepository by lazy {
        // Implementación de red para Desktop o stub
        StubMarsPhotosRepository()
    }

    override val snRepository: SNRepository by lazy {
        StubSNRepository()
    }

    override val localRepository: LocalRepository by lazy {
        InMemoryLocalRepository()
    }

    override val mainRepository: MainRepository by lazy {
        MainRepository(localRepository, snRepository)
    }
}