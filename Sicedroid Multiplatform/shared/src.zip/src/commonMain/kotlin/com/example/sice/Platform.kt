package com.example.sice

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform