package com.example.sice.models

data class CalificacionUnidadItem(
    val materia: String,
    val grupo: String,
    val observaciones: String,
    val unidadesActivas: String,
    val c1: String?,
    val c2: String?,
    val c3: String?,
    val c4: String?,
    val c5: String?,
    val c6: String?,
    val c7: String?,
    val c8: String?,
    val c9: String?,
    val c10: String?,
    val c11: String?,
    val c12: String?,
    val c13: String?
)

