package com.example.sice.data

import com.example.marsphotos.repository.LocalRepository
import com.example.sice.models.CalificacionFinalItem
import com.example.sice.models.CalificacionUnidadItem
import com.example.sice.models.CardexItem
import com.example.sice.models.CargaItem
import com.example.sice.models.ProfileStudent
import kotlinx.coroutines.flow.firstOrNull


class MainRepository(
    private val local: LocalRepository,
    private val remote: SNRepository
) {


    fun getCurrentMatricula(): String? = remote.getCurrentMatricula()
    fun setCurrentMatricula(matricula: String?) = remote.setCurrentMatricula(matricula)

    suspend fun acceso(m: String, p: String): Result<String> = try {
        Result.success(remote.acceso(m, p))
    } catch (t: Throwable) {
        Result.failure(t)
    }

    fun hasSession(): Boolean = remote.hasSession()
    fun logout() = remote.logout()

    suspend fun getProfile(matricula: String, online: Boolean): Result<ProfileStudent?> = try {
        if (online) {
            remote.profile()?.let { local.insertProfile(it) }
        }
        val profile = local.getProfile(matricula).firstOrNull()
        Result.success(profile)
    } catch (t: Throwable) {
        Result.failure(t)
    }

    suspend fun getCardex(matricula: String, lineamiento: Int, online: Boolean): Result<List<CardexItem>?> = try {
        if (online) {
            // remote.cardex devuelve Pair<List<CardexItem>, PromedioInfo>
            val response = remote.cardex(lineamiento)
            response?.let { (items, promedio) ->
                // insertar la lista en local
                local.insertCardex(matricula, items)
            }
        }

        val list = local.getCardex(matricula).firstOrNull()
        Result.success(list)
    } catch (t: Throwable) {
        Result.failure(t)
    }


    suspend fun getCarga(matricula: String, online: Boolean): Result<List<CargaItem>?> = try {
        if (online) {
            remote.cargaAcademica()?.let { local.insertCarga(matricula, it) }
        }
        val list = local.getCarga(matricula).firstOrNull()
        Result.success(list)
    } catch (t: Throwable) {
        Result.failure(t)
    }

    suspend fun getCalificaciones(matricula: String, online: Boolean): Result<List<CalificacionUnidadItem>?> = try {
        if (online) {
            remote.calificacionesPorUnidad()?.let { local.insertCalificaciones(matricula, it) }
        }
        val list = local.getCalificaciones(matricula).firstOrNull()
        Result.success(list)
    } catch (t: Throwable) {
        Result.failure(t)
    }

    suspend fun getCalificacionFinal(matricula: String, modEducativo: Int, online: Boolean): Result<List<CalificacionFinalItem>?> = try {
        if (online) {
            remote.calificacionFinal(modEducativo)?.let { local.insertCalificacionFinal(matricula, it) }
        }
        val list = local.getCalificacionFinal(matricula).firstOrNull()
        Result.success(list)
    } catch (t: Throwable) {
        Result.failure(t)
    }
}