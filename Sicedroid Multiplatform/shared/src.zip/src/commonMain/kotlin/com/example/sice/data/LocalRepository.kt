package com.example.marsphotos.repository

import com.example.sice.models.CalificacionFinalItem
import com.example.sice.models.CalificacionUnidadItem
import com.example.sice.models.CardexItem
import com.example.sice.models.CargaItem
import com.example.sice.models.ProfileStudent
import com.example.sice.models.PromedioInfo
import kotlinx.coroutines.flow.Flow


interface LocalRepository {
    suspend fun insertCardex(matricula: String, items: List<CardexItem>)

    fun getCardex(matricula: String): Flow<List<CardexItem>>

    suspend fun insertCarga(matricula: String, items: List<CargaItem>)
    fun getCarga(matricula: String): Flow<List<CargaItem>>

    suspend fun insertCalificaciones(matricula: String, items: List<CalificacionUnidadItem>)
    fun getCalificaciones(matricula: String): Flow<List<CalificacionUnidadItem>>

    suspend fun insertCalificacionFinal(matricula: String, items: List<CalificacionFinalItem>)
    fun getCalificacionFinal(matricula: String): Flow<List<CalificacionFinalItem>>

    // Métodos para perfil (necesarios para MainRepository)
    fun getProfile(matricula: String): Flow<ProfileStudent?>
    suspend fun insertProfile(profile: ProfileStudent)


}