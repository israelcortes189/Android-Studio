package com.example.sice.ui

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.sice.App
import com.example.sice.data.MainRepository

class SNViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val container = (application as App).container
        val mainRepo: MainRepository = container.mainRepository

        @Suppress("UNCHECKED_CAST")
        return SNViewModel(repository = mainRepo, appContext = application.applicationContext) as T
    }
}