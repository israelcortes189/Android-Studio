package com.example.sice

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.sice.di.AppContainer
import com.example.sice.di.DefaultAppContainer
import com.example.sice.ui.SNViewModel
import com.example.sice.ui.SNViewModelFactory

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Obtén el container desde la Application (no crear uno nuevo)
        val appContainer = (application as App).container

        enableEdgeToEdge()

        setContent {
            val factory = SNViewModelFactory(application)
            val viewModel: SNViewModel = viewModel(factory = factory)

            App(
                mainRepository = appContainer.mainRepository,
                localRepository = appContainer.localRepository,
                marsPhotosRepository = appContainer.marsPhotosRepository,
                snViewModel = viewModel
            )
        }
    }
}