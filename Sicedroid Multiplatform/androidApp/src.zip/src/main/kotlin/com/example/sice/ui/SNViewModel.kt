package com.example.sice.ui

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.asFlow
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.example.marsphotos.data.Entityes.CalificacionFinalEntity
import com.example.marsphotos.data.Entityes.CalificacionUnidadEntity
import com.example.marsphotos.data.Entityes.CardexEntity
import com.example.marsphotos.data.Entityes.CargaEntity
import com.example.marsphotos.data.Entityes.ProfileEntity
import com.example.sice.data.MainRepository
import com.example.sice.models.CalificacionFinalItem
import com.example.sice.models.CalificacionUnidadItem
import com.example.sice.models.CardexItem
import com.example.sice.models.CargaItem
import com.example.sice.models.ProfileStudent
import com.example.sice.util.isOnline
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface SNUiState {
    data class Success(val accesoLogin: String) : SNUiState
    object Error : SNUiState
    object Loading : SNUiState
}

class SNViewModel(
    private val repository: MainRepository,
    private val appContext: Context,

) : ViewModel() {

    var snUiState: SNUiState by androidx.compose.runtime.mutableStateOf(SNUiState.Loading)
        private set

    var profileState by androidx.compose.runtime.mutableStateOf<ProfileStudent?>(null)
        private set

    var isLoading by androidx.compose.runtime.mutableStateOf(false)
        private set

    private val _cardexState = MutableStateFlow<List<CardexItem>>(emptyList())
    val cardexState = _cardexState.asStateFlow()


    private val _calificacionesState = MutableStateFlow<List<CalificacionUnidadItem>>(emptyList())
    val calificacionesState = _calificacionesState.asStateFlow()

    private val _cargaState = MutableStateFlow<List<CargaItem>>(emptyList())
    val cargaState = _cargaState.asStateFlow()

    private val _califFinalState = MutableStateFlow<List<CalificacionFinalItem>>(emptyList())
    val califFinalState = _califFinalState.asStateFlow()

    private val _syncState = MutableStateFlow<WorkInfo?>(null)
    val syncState = _syncState.asStateFlow()

    init {
        checkSession()
    }

    /**
     * Generic loader for repository methods that return List<T>? (Entities)
     * callRepo: suspend (matricula, online) -> List<T>?
     */
    // Firma nueva: callRepo devuelve Result<List<T>?>
    fun <T> loadDataGeneric(
        tipo: String,
        stateFlow: MutableStateFlow<List<T>>,
        callRepo: suspend (String, Boolean) -> Result<List<T>?>
    ) {
        val mat = getSavedMatricula() ?: run {
            snUiState = SNUiState.Error
            return
        }

        viewModelScope.launch {
            snUiState = SNUiState.Loading
            try {
                val online = isOnline(appContext)
                val result = withContext(Dispatchers.IO) {
                    if (online) {
                        // intenta online y si falla hace fallback a local
                        val r = callRepo(mat, true)
                        if (r.isSuccess) r else callRepo(mat, false)
                    } else {
                        callRepo(mat, false)
                    }
                }

                result.fold(onSuccess = { data ->
                    if (!data.isNullOrEmpty()) {
                        stateFlow.value = data
                        if (online) syncData(tipo, mat)
                        snUiState = SNUiState.Success("${tipo}Loaded")
                    } else {
                        stateFlow.value = emptyList()
                        snUiState = SNUiState.Error
                    }
                }, onFailure = { t ->
                    Log.e("SNViewModel", "Error cargando $tipo", t)
                    snUiState = SNUiState.Error
                })
            } catch (e: Exception) {
                Log.e("SNViewModel", "Excepción en loadDataGeneric", e)
                snUiState = SNUiState.Error
            }
        }
    }


    fun hasSession(): Boolean = repository.hasSession()

    fun logout() {
        repository.logout()
        profileState = null
        appContext.getSharedPreferences("session", Context.MODE_PRIVATE).edit().clear().apply()
        snUiState = SNUiState.Loading
    }

    fun loadProfile(matriculaParam: String? = null) {
        val mat = matriculaParam ?: getSavedMatricula() ?: return
        viewModelScope.launch {
            isLoading = true
            snUiState = SNUiState.Loading
            val online = isOnline(appContext)
            try {
                val result = withContext(Dispatchers.IO) { repository.getProfile(mat, online) }
                result.fold(onSuccess = { perfil ->
                    if (perfil != null) {
                        profileState = perfil
                        snUiState = SNUiState.Success(if (online) "Online" else "Offline")
                        if (online) syncData("perfil", mat)
                    } else {
                        snUiState = SNUiState.Error
                    }
                }, onFailure = { t ->
                    Log.e("SNViewModel", "Error loadProfile", t)
                    snUiState = SNUiState.Error
                })
            } finally {
                isLoading = false
            }
        }
    }


    private fun checkSession() {
        viewModelScope.launch {
            val prefs = appContext.getSharedPreferences("session", Context.MODE_PRIVATE)
            val hasSessionPref = prefs.getBoolean("hasSession", false)

            if (!repository.hasSession() && !hasSessionPref) {
                snUiState = SNUiState.Error
                return@launch
            }

            // Reconstruir matrícula si hace falta
            val currentMat = repository.getCurrentMatricula()
            if (currentMat.isNullOrBlank()) {
                val saved = prefs.getString("matricula", null)
                if (!saved.isNullOrBlank()) {
                    repository.setCurrentMatricula(saved)
                }
            }

            val matricula = repository.getCurrentMatricula() ?: return@launch

            if (isOnline(appContext)) {
                try {
                    val result = withContext(Dispatchers.IO) { repository.getProfile(matricula, true) }
                    result.fold(onSuccess = { profile ->
                        if (profile != null) {
                            profileState = profile
                            snUiState = SNUiState.Success("Online")
                            return@launch
                        }
                        // si profile es null, seguimos al fallback offline
                    }, onFailure = { t ->
                        Log.e("SESSION", "Error al obtener perfil online", t)
                    })
                } catch (e: Exception) {
                    Log.e("SESSION", "Excepción al intentar perfil online", e)
                }
            }

            // Fallback offline
            try {
                val offlineResult = withContext(Dispatchers.IO) { repository.getProfile(matricula, false) }
                offlineResult.fold(onSuccess = { profile ->
                    if (profile != null) {
                        profileState = profile
                        snUiState = SNUiState.Success("Offline")
                    } else {
                        repository.logout()
                        prefs.edit().clear().apply()
                        snUiState = SNUiState.Error
                    }
                }, onFailure = { t ->
                    Log.e("SESSION", "Error leyendo perfil offline", t)
                    repository.logout()
                    prefs.edit().clear().apply()
                    snUiState = SNUiState.Error
                })
            } catch (e: Exception) {
                Log.e("SESSION", "Excepción en fallback offline", e)
                repository.logout()
                prefs.edit().clear().apply()
                snUiState = SNUiState.Error
            }
        }
    }


    fun accesoSN(usuario: String, password: String) {
        viewModelScope.launch {
            snUiState = SNUiState.Loading
            try {
                val result = withContext(Dispatchers.IO) { repository.acceso(usuario, password) }
                val value = result.getOrNull()
                if (value == "OK") {
                    val mat = repository.getCurrentMatricula()
                    saveSession(mat)
                    loadProfile(mat)
                } else {
                    snUiState = SNUiState.Error
                }

            } catch (e: Exception) {
                Log.e("SNViewModel", "Error accesoSN", e)
                snUiState = SNUiState.Error
            }
        }
    }

    private fun getSavedMatricula(): String? {
        val prefs = appContext.getSharedPreferences("session", Context.MODE_PRIVATE)
        return repository.getCurrentMatricula() ?: prefs.getString("matricula", null)
    }

    private fun saveSession(mat: String?) {
        appContext.getSharedPreferences("session", Context.MODE_PRIVATE).edit()
            .putString("matricula", mat)
            .putBoolean("hasSession", true)
            .apply()
    }


    fun loadCardex() = loadDataGeneric("cardex", _cardexState) { m, o ->
        repository.getCardex(m, 1, o)
    }

    fun loadCalificacionesPorUnidad() = loadDataGeneric("califUnidades", _calificacionesState) { m, o ->
        repository.getCalificaciones(m, o)
    }

    fun loadCargaAcademica() = loadDataGeneric("carga", _cargaState) { m, o ->
        repository.getCarga(m, o)
    }

    fun loadCalificacionFinal() = loadDataGeneric("califFinal", _califFinalState) { m, o ->
        repository.getCalificacionFinal(m, 1, o)
    }


    fun syncData(tipo: String, matricula: String) {
        val uniqueName = "sync_${tipo}_$matricula"
        val wm = WorkManager.getInstance(appContext)

        //val remoteRequest = OneTimeWorkRequestBuilder<com.example.sice.work.RemoteWorker>()
            //.setInputData(workDataOf("tipo" to tipo, "matricula" to matricula)).build()
        //val localRequest = OneTimeWorkRequestBuilder<com.example.sice.work.LocalWorker>()
            //.setInputData(workDataOf("tipo" to tipo, "matricula" to matricula, "remoteId" to remoteRequest.id.toString())).build()

        //wm.beginUniqueWork(uniqueName, ExistingWorkPolicy.KEEP, remoteRequest).then(localRequest).enqueue()

        viewModelScope.launch {
            wm.getWorkInfosForUniqueWorkLiveData(uniqueName).asFlow().collect { list ->
                _syncState.value = list.lastOrNull()
            }
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = (this[APPLICATION_KEY] as Application)
                val container = (application as com.example.sice.App).container
                val mainRepo = container.mainRepository
                SNViewModel(repository = mainRepo, appContext = application.applicationContext)
            }
        }
    }
}