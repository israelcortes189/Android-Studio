package com.example.sice.data

import com.example.sice.Network.MarsApiService
import com.example.sice.model.MarsPhoto

class NetworkMarsPhotosRepository(
    private val marsApiService: MarsApiService
) : MarsPhotosRepository {
    override suspend fun getMarsPhotos(): List<MarsPhoto> = marsApiService.getPhotos()
}