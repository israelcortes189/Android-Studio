package com.example.sice

import android.app.Application
import com.example.sice.di.DefaultAppContainer

class App : Application() {
    // crea el container una sola vez usando el ApplicationContext
    val container: DefaultAppContainer by lazy { DefaultAppContainer(applicationContext) }
}